package logica

data class Topic(var titulo:String= "titulo", var subtitle:String="subtitulo", var description:String="descripcion")
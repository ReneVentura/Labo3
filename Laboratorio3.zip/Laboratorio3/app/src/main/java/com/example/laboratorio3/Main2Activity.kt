package com.example.laboratorio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.laboratorio3.databinding.ActivityMain2Binding
import logica.Topic

class Main2Activity : AppCompatActivity() {
    private lateinit var binding2: ActivityMain2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding2= DataBindingUtil.setContentView(this,R.layout.activity_main2)

        info()

        binding2.comt.setOnClickListener {

            comentario()
        }
    }



    private fun info(){
        val obIntent: Intent = intent
        val r= obIntent.getStringExtra("Code")
        val topic:Topic= Topic()
        binding2.topic=topic
        if(r== "sint"){
            topic.titulo="Sintomas"
            topic.subtitle= "Sintomas del coronavirus"
            topic.description="Los signos y síntomas deCOVID-19,pueden aparecer entre dos y 14 días después de estar expuesto, y pueden incluir:\n" +
                    "\n" +
                    "    Fiebre\n" +
                    "    Tos\n" +
                    "    Falta de aire o dificultad para respirar\n" +
                    "\n" +
                    "Otros síntomas pueden incluir:\n" +
                    "\n" +
                    "    Cansancio\n" +
                    "    Dolores\n" +
                    "    Goteo de la nariz\n" +
                    "    Dolor de garganta\n" +
                    "    Dolor de cabeza\n" +
                    "    Diarrea\n" +
                    "    Vómitos\n" +
                    "\n" +
                    "Algunas personas pierden el sentido del olfato o del gusto.\n" +
                    "\n" +
                    "La gravedad de los síntomas deCOVID-19,puede ser de muy leve a seria. Algunas personas no tienen ningún síntoma. Los adultos mayores o las personas que tienen ciertas afecciones crónicas, como enfermedades cardíacas o pulmonares, o diabetes, o que tienen un sistema inmunitario comprometido, pueden correr un riesgo más alto de enfermarse de gravedad. Esto es similar a lo que se ve con otras enfermedades respiratorias, como la influenza (gripe)."

        }
        else if (r== "prec"){
            topic.titulo="Precauciones"
            topic.subtitle= "Precauciones para el coronavirus"
            topic.description="Hasta la fecha no se dispone de vacuna para combatir las infecciones por coronavirus. Por eso, conocer cómo se transmiten es fundamental para establecer medidas de prevención. Los coronavirus son virus de transmisión aérea. Se transmiten por vía respiratoria a través de las gotas que producen los portadores cuando tosen, estornudan o hablan.\n" +
                    "\n" +
                    "Estas secreciones contienen partículas virales que pueden alcanzar a personas cercanas o depositarse en objetos y superficies próximas. Si alguien toca estas superficies y a continuación se lleva las manos a sus propios ojos, nariz o boca, el patógeno encuentra una vía para entrar en el organismo.\n" +
                    "\n" +
                    "Se ha constatado que el coronavirus más reciente, el SARS-CoV-2, puede sobrevivir en diversas superficies durante varias horas (cobre, cartón) e incluso algunos días (plástico, acero inoxidable). No obstante, hay que tener en cuenta que la cantidad de virus viable desciende con el tiempo y que no siempre está presente en esas superficies en una cantidad suficiente para provocar infección.\n" +
                    "\n" +
                    "Mantener una higiene básica es la forma más eficaz de evitar contraer este virus en los lugares en los que existe un mayor riesgo de transmisión, fundamentalmente las zonas en las que se han registrado casos. Es conveniente lavarse las manos con frecuencia y evitar el contacto con personas ya infectadas, protegiendo especialmente ojos, nariz y boca. A las personas infectadas (o que crean que pueden estarlo) se les aconseja el uso de mascarillas y usar pañuelos para cubrirse la nariz y la boca cuando se tose o se estornuda.\n" +
                    "\n" +
                    "Las personas infectadas por el virus que causa el Covid-19 deben guardar cuarentena desde el diagnóstico de la enfermedad hasta 15 días después de ser dadas de alta. Así lo aconseja la OMS porque se ha observado que, aunque ya estén recuperadas, pueden seguir transmitiendo la infección.\n" +
                    "\n" +
                    "Además, se ha observado que los infectados asintomáticos, o bien aquellos que todavía no han desarrollado síntomas, pueden transmitir el virus.\n" +
                    "\n" +
                    "Las recomendaciones sobre el uso de mascarillas han ido cambiando desde que se inició la pandemia de Covid-19 a finales de 2020. En un pricipio se aconsejaban solo a quienes están infectados, pero cada vez son más los organismos internacionales que abogan por un empleo generalizado entre la población, tanto sana como infectada por el SARS-CoV-2.\n" +
                    "\n" +
                    "En España, el Ministerio de Sanidad ha advertido de que un uso inadecuado de mascarillas puede contribuir al desabastecimiento en aquellas situaciones para las que están más indicadas. Aunque se han empezado a repartir mascarillas en lugares públicos, las autoridades sanitarias han anunciado que su uso solo será obligatorio cuando estén disponibles para todo el mundo.\n" +
                    "\n" +
                    "Las medidas preventivas deben seguirlas especialmente aquellas personas que padezcan diabetes, insuficiencia renal, neumopatía crónica o inmunodepresión, ya que tienen más riesgo de padecer enfermedad grave en caso de infección por coronavirus. "



        }

        else if( r=="virus"){
            topic.titulo="Coronavirus"
            topic.subtitle= "Que es el coronavirus?"
            topic.description="Los coronavirus son una familia de virus que se descubrió en la década de los 60 pero cuyo origen es todavía desconocido. Sus diferentes tipos provocan distintas enfermedades, desde un resfriado hasta un síndrome respiratorio grave (una forma grave de neumonía).\n" +
                    "\n" +
                    "Gran parte de los coronavirus no son peligrosos y se pueden tratar de forma eficaz. De hecho, la mayoría de las personas contraen en algún momento de su vida un coronavirus, generalmente durante su infancia. Aunque son más frecuentes en otoño o invierno, se pueden adquirir en cualquier época del año.\n" +
                    "\n" +
                    "El coronavirus debe su nombre al aspecto que presenta, ya que es muy parecido a una corona o un halo. Se trata de un tipo de virus presente sobre todo en los animales, pero también en los humanos."


        }



    }

    private fun comentario(){
        val comentario= binding2.comentar.text.toString()
        val clave= "r"
        val intent: Intent = Intent(this, MainActivity::class.java)
        intent.putExtra("comentari",comentario)
        intent.putExtra("c",clave)
        startActivity(intent)



    }
}

package com.example.laboratorio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.laboratorio3.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding :ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= DataBindingUtil.setContentView(this,R.layout.activity_main)

        binding.check.setOnClickListener{

            verificar()

        }
        binding.sintomas.setOnClickListener {

            sintomas()
        }
        binding.prec.setOnClickListener {
            precauciones()
        }

        binding.virus.setOnClickListener {
            virus()
        }

        val obIntent: Intent = intent
        val key= obIntent.getStringExtra("c")
        if(key=="r"){
            val valor= obIntent.getStringExtra("comentari")
            Toast.makeText(this, valor, Toast.LENGTH_SHORT).show()


        }

    }

    private fun verificar(){

        val estado= binding.status
        val nombre= binding.nametext.text.toString()
        val edad= binding.edadtext.text.toString().toInt()
        when(edad){
            in 15..40 -> estado.text= nombre+" no estas en grave peligro, aun asi toma precauciones."
            in 41..60-> estado.text= nombre+" debido a tu edad estan en leve peligro, toma precauciones."
            in 61..100-> estado.text= nombre+" debido a tu edad estas en grave peligro, no salgas de casa y porfavor toma precauciones."

        }


        binding.edadtext.visibility= View.GONE
        binding.nametext.visibility= View.GONE
        binding.check.visibility=View.GONE
        binding.textView3.visibility=View.GONE
        binding.textView4.visibility=View.GONE
        binding.status.visibility=View.VISIBLE


    }
    private fun sintomas(){
        val code= "sint"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }
    private fun precauciones(){
        val code= "prec"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }

    private fun virus(){
        val code= "virus"
        val intent: Intent = Intent(this, Main2Activity::class.java)
        intent.putExtra("Code",code)
        startActivity(intent)
    }
}




